import hashlib
import getpass
import Salt
files = ['1:d8f139987becb1a316c43332487f16adbdd9fe7572cb359af488cea080ce611a', '2:aea811b21ddb7fafc82fb1f34c58ac6680e2323b38fe232c190a57562c38a754' , '3:ad8d262ea9af5a3c6ddd415c5d50c9a9033677a6d42057bea4ae8487454eddd5','4:df321454d2cd784bc433e7ef2e335e5a8446afeeb9edfb2dc47ca144dd9d0e24','5:e415300d1dead3a822392ba89a3bb40eda857d1e50e247996431f231e2e7b51c']
op = 'y'
while op == 'y':
    log = str(input(
        "Login (l)  Signup (s)    Change Username/password (c)   Delete Account (d)  Search Username (f)  Press Your Options  :"))

    if log == 's':
        adminpassword = "fb9db2c591544dcec35440ab58c6a0d91c6367812c150a70f1370a22e3e6e805"
        adminname = "admin"
        root = adminname + adminpassword
        useradmin = input("Enter Administrator Name     :")
        getpassword = getpass.getpass(prompt="Enter Admin Password : ")
        SaltedAdminPass = Salt.String_Hashing(getpassword)
        encodedPassword = hashlib.sha256(SaltedAdminPass.encode())
        passadmin = encodedPassword.hexdigest()
        troot = useradmin + passadmin
        if troot == root:
            newuser = input("Enter New User Name    :")
            getpasswordNewU = getpass.getpass("Enter Password     :")
            SaltedPassword = Salt.String_Hashing(getpasswordNewU)
            
            encodedUserPassword = hashlib.sha256(SaltedPassword.encode())
            newpass = encodedUserPassword.hexdigest()

            getPassConfirm = getpass.getpass("Confirm Password     :")
            SaltedConfirmPass =Salt.String_Hashing(getPassConfirm)
            
            encodedUserConfPassword = hashlib.sha256(SaltedConfirmPass.encode())
            newpass1 = encodedUserConfPassword.hexdigest()
            if newpass == newpass1:
                print("Password Confirmed")
                print("New User added")
                new = str(newuser + ":" + newpass1)
                files = files + [new]
                print(files[-1])
            else:
                print("Password nor match !!! please Try agian!!!")

        else:
            print("Administrator Incorrect!!")

    elif log == 'l':
        print("Login Your Account")
        username = input("Enter Your Username   :")
        getpassPass = getpass.getpass("Enter Your Password  :")
        SaltedPassword = Salt.String_Hashing(getpassPass)
        result = hashlib.sha256(SaltedPassword.encode())
        password = result.hexdigest()
        total = username + ":" + password
        lenpass = str(len(password))
        print("Length of Password is :" + lenpass)
        key = "no"
        print("Your name is :" + username)
        
        
        for x in files:
            if total == x:
                key = "yes"
                break


            else:
                key = "no"
        if key == "yes":
            print("Login Successufull")
        else:
            print("Login Incorrect")
    elif log == 'c':
        print('Login Your Account')
        username = input("Enter Your Username")
        getPassword = getpass.getpass("Enter Your Password")
        SaltedPassword = Salt.String_Hashing(getPassword)
        result = hashlib.sha256(SaltedPassword.encode())
        password = result.hexdigest()
        total = username + ":" + password
        lenpass = str(len(password))
        print("Length of Password is :" + lenpass)
        key = "no"
        print("Your name is :" + username)
        
        
        i = -1
        for x in files:
            i = i + 1
            if total == x:
                key = "yes"
                break
            else:
                key = "no"
        if key == "yes":
            print("Login Successufull")
            print("")
            cname = input("Enter new Userame    :")
            cgetPassword = getpass.getpass("Enter new password   :")
            SaltedCPassword = Salt.String_Hashing(cgetPassword)
            resultcpass = hashlib.sha256(SaltedCPassword.encode())
            cpass = resultcpass.hexdigest()
            cgetPasswordConfirm = getpass.getpass("Confirm your password   :")
            SaltedcConfimPassword = Salt.String_Hashing(cgetPasswordConfirm)
            resultcpass1 = hashlib.sha256(SaltedcConfimPassword.encode())
            cpass1 = resultcpass1.hexdigest()
            if cpass == cpass1:
                print("Username is  :" + cname)
                print("Password is Confirmed")
                caccount = cname + ':' + cpass
                files[i] = caccount
                print("New Username & Password are added")

            else:
                print("Password not match !!!")
                exit(0)
        else:
            print("Login Incorrect")
            exit(0)
    elif log == 'd':
        if len(files) == 0:
            print("users are empty try Signup !!!")
        else:
            print("Login Your Account")
            username = input("Enter Your Username")
            dgetPassword = getpass.getpass("Enter Your Password")
            SalteddPassword = Salt.String_Hashing(dgetPassword)
            resultdpass = hashlib.sha256(SalteddPassword.encode())
            password = resultdpass.hexdigest()
            total = username + ":" + password
            lenpass = str(len(password))
            print("Length of Password is :" + lenpass)
            key = "no"
            print("Your name is :" + username)
            lenfiles = len(files)
            print("Lenght of files is   :" + str(lenfiles))
            i = -1
            for x in files:
                i = i + 1
                if total == x:
                    key = "yes"
                    break


                else:
                    key = "no"
            if key == "yes":
                print("Login Successufull")
                print("Deleting Your Acoount")
                print(files)

                del files[i]
                print(files)
                print("Account Deleted")

            else:
                print("Login Incorrect")

    elif log == 'f':
        name = input('Enter Username want to Search     :')
        lenofname = len(name)
        key = 'no'
        i = 0
        for a in files:
            k = a
            for k in a:
                if a[0:lenofname] == name:
                    key = 'yes'
                    print("Found")
                    break
            if key == 'yes':
                break
        if key == 'no':
            print('NOT FOUND')

    else:
        print('Invaild Option Select an Option From')
        print('Login (l)  Signup (s)    Change Username/password (c) Delete Account (d)')

    op = input('Do you want to continue : press "y" or "n"  :')
    if op != ('y'):
        exit(0)

# Author :Mohamed Ansaf;mail:ansafmattathur@gmail.com;followmeoninstagram:anu_ansaf.3;

