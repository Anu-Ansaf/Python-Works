file = open('StoreHash.txt','r')
readFile = file.readlines()

for x in range(0, len(readFile), 1):
    readFile[x] = readFile[x].strip('\n')

def saltingshashSelector(strings):
    lenghtofstring = int(len(strings))
    hashSelector = lenghtofstring % 14
    return (hashSelector)
def saltingstring(string,HashSelected):
    lenofstring = len(string)
    half = int(lenofstring / 2)
    left = string[0:half]
    right = string[half:lenofstring]

    value = readFile[HashSelected]
    salted = left + value + right
    return salted


def String_Hashing(string):
    value = saltingshashSelector(string)
    return saltingstring(string,value)

